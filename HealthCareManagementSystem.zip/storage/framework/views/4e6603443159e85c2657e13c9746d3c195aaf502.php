
<?php $__env->startPush('css'); ?>
<link href="<?php echo e(asset('css/table.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('css/form.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<form action="<?php echo e(url('appointment/create')); ?>"><button>Book an Appointment</button></form>
<?php $__env->startPush('js'); ?>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PHP\HealthCareManagementSystem\resources\views/patient/patient.blade.php ENDPATH**/ ?>