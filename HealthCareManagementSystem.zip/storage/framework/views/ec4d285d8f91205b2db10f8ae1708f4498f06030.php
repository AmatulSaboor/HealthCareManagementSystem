
<?php $__env->startPush('css'); ?>
<link href="<?php echo e(asset('css/table.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('css/form.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="container" class ="index">
    <h4>Doctors List</h4>
    <span><?php echo e(session()->get('error_message')); ?></span>
    <form action="<?php echo e(url('doctor/create')); ?>"><button>Add New Doctor</button></form>
    <table>
        <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Eductaion</th>
            <th>Specialization</th>
            <th>Designation</th>
            <th>Experience</th>
            <th>Age</th>
            <th>Gender</th>
            <th>Working Days</th>
            <th>Timings</th>
            <th>Charges</th>
            <th></th>
            <th></th>
        </tr>
        <?php $__currentLoopData = $doctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doctor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($doctor->name); ?></td>
            <td><?php echo e($doctor->email); ?></td>
            <?php if($doctor && $doctor->doctorDetail): ?>
            <td><?php echo e($doctor->doctorDetail->education->name); ?></td>
            <td><?php echo e($doctor->doctorDetail->specialization->name); ?></td>
            <td><?php echo e($doctor->doctorDetail->designation->name); ?></td>
            <td><?php echo e($doctor->doctorDetail->experience); ?></td>
            <td><?php echo \Carbon\Carbon::parse($doctor->doctorDetail->dob)->age; ?></td>
            <td><?php echo e($doctor->doctorDetail->gender); ?></td>
            <td><?php echo e($doctor->doctorDetail->working_days); ?></td>
            <td><?php echo e($doctor->doctorDetail->start_time. ' to ' .$doctor->doctorDetail->end_time); ?></td>
            <td><?php echo e($doctor->doctorDetail->charges); ?></td>
            <?php endif; ?>
            <td><a href="<?php echo e(url('doctor').'/'.$doctor->id.'/edit'); ?>">Edit</a></td>
            <th>
                <form action="<?php echo e(url('doctor').'/'.$doctor->id); ?>" method ="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('delete'); ?>
                    <input type="submit" value ="delete"/>
                </form>
            </th>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</div>
<?php $__env->startPush('js'); ?>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PHP\HealthCareManagementSystem\resources\views/admin/admin.blade.php ENDPATH**/ ?>