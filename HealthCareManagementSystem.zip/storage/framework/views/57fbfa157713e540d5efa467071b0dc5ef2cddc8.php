
<?php $__env->startPush('css'); ?>
<link href="<?php echo e(asset('css/table.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('css/form.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="container" class ="index">
    <h4>Edit Doctor</h4>
    <span><?php echo e(session()->get('error_message')); ?></span>
    <form action="<?php echo e(url('doctor'. '/' .$doctor->id )); ?>" method="POST" class="form-container">
        <?php echo csrf_field(); ?>
        <?php echo method_field('put'); ?>
        <label for="name">Name</label>
        <input id="name" type="text" name ="name" value="<?php echo e(old('name', $doctor->name)); ?>"/>
        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="alert alert-danger"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        
        <label for="email">Email</label>
        <input id="email" type="text" name ="email" value="<?php echo e(old('email', $doctor->email)); ?>"/>
        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="alert alert-danger"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        
        <label>Education</label>
        <select name="education_id">
            <option value="" disabled selected hidden>choose education</option>
            <?php $__currentLoopData = $educations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $education): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($education->id); ?>" <?php echo e(old('education_id', $doctor->doctorDetail->education_id??'') == $education->id ? 'selected' : ''); ?>><?php echo e($education->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <?php $__errorArgs = ['education_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="alert alert-danger"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <label>Specialization</label>
        <select name="specialization_id">
            <option value="" disabled selected hidden>choose specialization</option>
            <?php $__currentLoopData = $specializations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $specialization): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($specialization->id); ?>" <?php echo e(old('specialization_id', $doctor->doctorDetail->specialization_id??'') == $specialization->id ? 'selected' : ''); ?>><?php echo e($specialization->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <?php $__errorArgs = ['specialization_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="alert alert-danger"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <label>Designation</label>
        <select name="designation_id">
            <option value="" disabled selected hidden>choose designation</option>
            <?php $__currentLoopData = $designations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $designation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($designation->id); ?>" <?php echo e(old('designation_id', $doctor->doctorDetail->designation_id??'') == $designation->id ? 'selected' : ''); ?>><?php echo e($designation->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <?php $__errorArgs = ['designation_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="alert alert-danger"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <label for="experience">Experience</label>
        <input id="experience" type="text" name ="experience" value="<?php echo e(old('experience', $doctor->doctorDetail->experience??'')); ?>"/>
        <?php $__errorArgs = ['experience'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="alert alert-danger"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <label for="dob">Date of Birth</label>
        <input id="dob" type="date" name ="dob" value="<?php echo e(old('dob', $doctor->doctorDetail->dob??'')); ?>" min="<?php echo e(date('Y-m-d', strtotime("-80 years", strtotime(date('Y-m-d'))))); ?>"  max="<?php echo e(date('Y-m-d', strtotime("-20 years", strtotime(date('Y-m-d'))))); ?>" />
        <?php $__errorArgs = ['dob'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="alert alert-danger"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <label>Gender</label>
        <input type="radio" id="male" name="gender" value="male"/>
        <label for="male">male</label>
        <input type="radio" id="female" name="gender" value="female"/>
        <label for="female">female</label>
        <label for="working_days">Working Days</label>
        <input type="checkbox" value="Monday" name="working_days[]"/><label>Monday</label>
        <input type="checkbox" value="Tuesday" name="working_days[]"/><label>Tuesday</label>
        <input type="checkbox" value="Wednesday" name="working_days[]"/><label>Wednesday</label>
        <input type="checkbox" value="Thursday" name="working_days[]"/><label>Thursday</label>
        
        <label for="start_time">Start Time</label>
        <input id="start_time" type="time" name ="start_time" value="<?php echo e(old('start_time', $doctor->doctorDetail->start_time??'')); ?>"/>
        <?php $__errorArgs = ['start_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="alert alert-danger"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <label for="end_time">End Time</label>
        <input id="end_time" type="time" name ="end_time" value="<?php echo e(old('end_time', $doctor->doctorDetail->end_time??'')); ?>"/>
        <?php $__errorArgs = ['end_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="alert alert-danger"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <label for="charges">Charges</label>
        <input id="charges" type="text" name ="charges" value="<?php echo e(old('charges', $doctor->doctorDetail->charges??'')); ?>"/>
        <?php $__errorArgs = ['charges'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="alert alert-danger"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <input type ="submit" value = "Save" name ="submit"/>
    </form>
</div>
<?php $__env->startPush('js'); ?>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PHP\HealthCareManagementSystem\resources\views/admin/edit_doctor.blade.php ENDPATH**/ ?>